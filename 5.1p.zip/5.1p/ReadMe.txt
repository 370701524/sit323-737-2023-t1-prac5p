For P:
    I completed the homework for P and C together, so I placed it in a project.
When testing task.P, you should first use" node server. js "to start the server, 
and then use the four client terminals of addition, subtraction, multiplication,
and division to send a request for testing. Switch to the http file, and click" send request "to see the results.

For C:
    For task.C, also use node server.js to start the server, then open request.htm and click "send request" to send the request, 
    then obtain the token, copy and paste the token into the second port, and then click "send request" to see that the 
    verification has passed.
