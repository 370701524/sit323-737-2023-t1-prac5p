const express = require('express');
const app = express();
//Middleware
const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const bodyParser = require('body-parser');
const jwt =require('jsonwebtoken');
app.use(bodyParser.json());
//JWT Strategy
const jwtOptions = {
  secretOrKey: 'hpjdakdjawncamwidjmian',
  //The jwtFromRequest property specifies how the JWT should be extracted 
  //from ExtractJwt.from AuthHeaderAsBearerToken() is passport-jwt moduleAuthorization header
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
};
// Define JWT strategy
passport.use(
  new JwtStrategy(jwtOptions, (jwtPayload, done) => {
    if (jwtPayload.username === 'hpj') {
      return done(null, { username: 'hpj' });
    } else {
      return done(null, false);
    }
  })
);
const jwtkey ='hpjdakdjawncamwidjmian';
//USER & port
const user = {username: 'hpj', password:'LOVEYUE'};
const port = 3200;
//LOGIN
app.post('/login',(req,res) =>{
  
  const {username,password}=req.body;
   if(username === user.username&& password === user.password){
    //Create token
    jwt.sign(
      {username},
      jwtkey,
      (err,token)=>{
        //Return token
        res.json({username, message: 'Login successful !!',token});
      }
    );
   }else {
    res.status(401).json({ message: 'Unauthorized' });
  }
});
//Vertication
app.get('/ok',passport.authenticate('jwt', { session: false }),(req,res)=>{
  const headers = req.headers;
  const token = headers['authorization'].split(' ')[1];
  jwt.verify(token,jwtkey,(err,payload)=>{
      if(err) res.sendStatus(403);
      res.json({message: 'Verification successful !!',payload});
  });
  
});
app.get('/addition', (req, res) => {
    try {
        const {num1,num2}=req.body;
        if(isNaN(num1)){
          throw new Error("num1 incorrectly defined");
        }
        if(isNaN(num2)){
          throw new Error("num2 incorrectly defined");
        }
        if (isNaN(num1) || isNaN(num2)) {
          throw new Error('Invalid input');
        }
        const result = num1 + num2;
        res.send("The result of addition is: "+result.toString());
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
});
// Define the subtraction endpoint
app.get('/subtraction', (req, res) => {
    try {
      const {num1,num2}=req.body;
        if(isNaN(num1)){
          throw new Error("num1 incorrectly defined");
        }
        if(isNaN(num2)){
          throw new Error("num2 incorrectly defined");
        }
        if (isNaN(num1) || isNaN(num2)) {
          throw new Error('Invalid input');
        }
        const result = num1 - num2;
        res.send("The result of subtraction is: "+result.toString());
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
   
});
// Define the multiplication endpoint
app.get('/multiplication', (req, res) => {
    try {
      const {num1,num2}=req.body;
        if(isNaN(num1)){
          throw new Error("num1 incorrectly defined");
        }
        if(isNaN(num2)){
          throw new Error("num2 incorrectly defined");
        }
        if (isNaN(num1) || isNaN(num2)) {
          throw new Error('Invalid input');
        }
        const result = num1 * num2;
        res.send("The result of multiplication is: "+result.toString());
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
});
// Define the division endpoint
app.get('/division', (req, res) => {
    try {
      const {num1,num2}=req.body;
        if(isNaN(num1)){
          throw new Error("num1 incorrectly defined");
        }
        if(isNaN(num2)){
          throw new Error("num2 incorrectly defined");
        }
        if (isNaN(num1) || isNaN(num2)) {
          throw new Error('Invalid input');
        }
        const result = num1/num2;
        res.send("The result of getting along is: "+result.toString());
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
});
    //listen
    app.listen(port,()=>console.log("Now you can access http://localhost:3200/<URL>"));